=== VoiceSpark ===
Contributors: voicespark
Tags: blog, publishing, scheduling, content, api
Requires at least: 5.8
Tested up to: 6.5
Requires PHP: 7.4
Stable tag: 1.0.0
License: MIT
License URI: https://spdx.org/licenses/MIT.html

VoiceSpark for WordPress allows you to publish and schedule blog posts directly from your VoiceSpark dashboard.

== Description ==

VoiceSpark plugin connects your WordPress site with the VoiceSpark platform, enabling you to:

* Publish blog posts directly from VoiceSpark dashboard
* Schedule posts for future publishing
* Manage categories and tags
* Set featured images
* Update and delete posts remotely
* Full SEO meta description support (Yoast compatible)

== Installation ==

1. Upload the `voicespark` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Connect your VoiceSpark account from the VoiceSpark dashboard

== Changelog ==

= 1.0.0 =
* Initial release
* JWT-based authentication
* Blog post creation and scheduling
* Category and tag management
* Featured image support
* SEO meta description support
