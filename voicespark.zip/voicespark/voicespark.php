<?php

/**
 * Plugin Name:       VoiceSpark
 * Plugin URI:        https://voicespark.ai
 * Description:       VoiceSpark for WordPress allows you to publish and schedule blog posts directly from your VoiceSpark dashboard to your WordPress site.
 * Version:           1.0.0
 * Author:            VoiceSpark
 * Author URI:        https://voicespark.ai
 * License:           MIT
 * License URI:       https://spdx.org/licenses/MIT.html
 * Text Domain:       voicespark
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

require_once dirname(__FILE__) . '/vendor/autoload.php';
use Firebase\JWT\JWT;
use Firebase\JWT\Key;


/**
 * Loader class to register WordPress hooks.
 */
class VoiceSpark_Auth_Loader
{
    protected $actions;
    protected $filters;

    public function __construct()
    {
        $this->actions = array();
        $this->filters = array();
    }

    public function add_plugin_action($hook, $component, $callback, $priority = 10, $accepted_args = 1)
    {
        $this->actions = $this->add($this->actions, $hook, $component, $callback, $priority, $accepted_args);
    }

    public function add_plugin_filter($hook, $component, $callback, $priority = 10, $accepted_args = 1)
    {
        $this->filters = $this->add($this->filters, $hook, $component, $callback, $priority, $accepted_args);
    }

    private function add($hooks, $hook, $component, $callback, $priority, $accepted_args)
    {
        $hooks[] = array(
            'hook' => $hook,
            'component' => $component,
            'callback' => $callback,
            'priority' => $priority,
            'accepted_args' => $accepted_args,
        );

        return $hooks;
    }

    public function run()
    {
        foreach ($this->filters as $hook) {
            add_filter($hook['hook'], array($hook['component'], $hook['callback']), $hook['priority'], $hook['accepted_args']);
        }

        foreach ($this->actions as $hook) {
            add_action($hook['hook'], array($hook['component'], $hook['callback']), $hook['priority'], $hook['accepted_args']);
        }
    }
}


/**
 * Main VoiceSpark Authentication & Publishing class.
 * 
 * Handles JWT-based authentication, blog post creation,
 * scheduled publishing, and permission checks.
 */
class VoiceSpark_Auth
{
    private $error = null;
    protected $namespace;
    protected $loader;

    public function __construct()
    {
        $this->namespace = 'voicespark/v1';
        $this->loader = new VoiceSpark_Auth_Loader();
        $this->define_public_hooks();
    }

    private function define_public_hooks()
    {
        $this->loader->add_plugin_action('rest_api_init', $this, 'add_api_routes');
        $this->loader->add_plugin_filter('rest_pre_dispatch', $this, 'rest_pre_dispatch');
        $this->loader->add_plugin_filter('determine_current_user', $this, 'determine_current_user');
    }

    public function run()
    {
        $this->loader->run();
    }

    /**
     * Register all REST API routes for VoiceSpark.
     */
    public function add_api_routes()
    {
        // Authentication - Generate JWT token
        register_rest_route($this->namespace, '/token', array(
            'methods' => "POST",
            'callback' => array($this, 'generate_token'),
            'permission_callback' => '__return_true'
        ));

        // Check if user can publish posts
        register_rest_route($this->namespace, '/can_publish', array(
            'methods' => "GET",
            'callback' => array($this, 'check_publish_permission'),
            'permission_callback' => '__return_true'
        ));

        // Create a new blog post (publish immediately or schedule)
        register_rest_route($this->namespace, '/posts', array(
            'methods' => "POST",
            'callback' => array($this, 'create_post'),
            'permission_callback' => '__return_true'
        ));

        // Update an existing blog post
        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => "PUT",
            'callback' => array($this, 'update_post'),
            'permission_callback' => '__return_true'
        ));

        // Delete a blog post
        register_rest_route($this->namespace, '/posts/(?P<id>\d+)', array(
            'methods' => "DELETE",
            'callback' => array($this, 'delete_post'),
            'permission_callback' => '__return_true'
        ));

        // Get all posts (for syncing)
        register_rest_route($this->namespace, '/posts', array(
            'methods' => "GET",
            'callback' => array($this, 'get_posts'),
            'permission_callback' => '__return_true'
        ));

        // Get site info (for connection verification)
        register_rest_route($this->namespace, '/site-info', array(
            'methods' => "GET",
            'callback' => array($this, 'get_site_info'),
            'permission_callback' => '__return_true'
        ));

        // Get available categories
        register_rest_route($this->namespace, '/categories', array(
            'methods' => "GET",
            'callback' => array($this, 'get_categories'),
            'permission_callback' => '__return_true'
        ));

        // Get available tags
        register_rest_route($this->namespace, '/tags', array(
            'methods' => "GET",
            'callback' => array($this, 'get_tags'),
            'permission_callback' => '__return_true'
        ));
    }

    /**
     * Generate a JWT token for authentication.
     */
    public function generate_token($request)
    {
        $secret_key = get_option('voicespark_secret');
        $username = $request->get_param('username');
        $password = $request->get_param('password');
        $user = wp_authenticate($username, $password);

        if (is_wp_error($user)) {
            $error_code = $user->get_error_code();
            return new WP_Error(
                $error_code,
                $user->get_error_message($error_code),
                array(
                    'status' => 401,
                )
            );
        }

        $issuedAt = time();
        $token = array(
            'iss' => get_bloginfo('url'),
            'iat' => $issuedAt,
            'nbf' => $issuedAt,
            'exp' => $issuedAt + 86400, // Token valid for 24 hours
            'data' => array(
                'user_id' => $user->data->ID,
            ),
        );

        return array(
            'token' => JWT::encode($token, $secret_key, 'HS256'),
            'user_display_name' => $user->data->display_name,
            'user_email' => $user->data->user_email,
        );
    }

    /**
     * Check if the authenticated user can publish posts.
     */
    public function check_publish_permission($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $user = get_userdata($user_id);

        if (!$user) {
            return new WP_Error('user_not_found', 'User not found', array('status' => 404));
        }

        if (user_can($user, 'publish_posts')) {
            return new WP_REST_Response(array('can_publish' => true), 200);
        } else {
            return new WP_REST_Response(array('can_publish' => false), 403);
        }
    }

    /**
     * Create a new blog post (supports immediate publish & scheduled posts).
     */
    public function create_post($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $user = get_userdata($user_id);
        if (!$user || !user_can($user, 'publish_posts')) {
            return new WP_Error(
                'insufficient_permissions',
                'You do not have permission to publish posts.',
                array('status' => 403)
            );
        }

        $title = sanitize_text_field($request->get_param('title'));
        $content = wp_kses_post($request->get_param('content'));
        $status = sanitize_text_field($request->get_param('status') ?? 'draft');
        $excerpt = sanitize_text_field($request->get_param('excerpt') ?? '');
        $categories = $request->get_param('categories') ?? array();
        $tags = $request->get_param('tags') ?? array();
        $scheduled_date = $request->get_param('scheduled_date'); // ISO 8601 format
        $featured_image_url = esc_url_raw($request->get_param('featured_image_url') ?? '');
        $slug = sanitize_title($request->get_param('slug') ?? '');
        $meta_description = sanitize_text_field($request->get_param('meta_description') ?? '');

        if (empty($title) || empty($content)) {
            return new WP_Error(
                'missing_fields',
                'Title and content are required.',
                array('status' => 400)
            );
        }

        // Handle scheduled posts
        $post_date = '';
        $post_date_gmt = '';
        if ($status === 'future' && !empty($scheduled_date)) {
            $post_date = get_date_from_gmt($scheduled_date);
            $post_date_gmt = $scheduled_date;
        }

        $post_data = array(
            'post_title'    => $title,
            'post_content'  => $content,
            'post_status'   => $status,
            'post_author'   => $user_id,
            'post_excerpt'  => $excerpt,
            'post_type'     => 'post',
        );

        if (!empty($slug)) {
            $post_data['post_name'] = $slug;
        }

        if (!empty($post_date)) {
            $post_data['post_date'] = $post_date;
            $post_data['post_date_gmt'] = $post_date_gmt;
        }

        $post_id = wp_insert_post($post_data, true);

        if (is_wp_error($post_id)) {
            return $post_id;
        }

        // Set categories
        if (!empty($categories)) {
            $cat_ids = array();
            foreach ($categories as $cat_name) {
                $cat = get_cat_ID($cat_name);
                if ($cat === 0) {
                    // Create the category if it doesn't exist
                    $new_cat = wp_create_category($cat_name);
                    if (!is_wp_error($new_cat)) {
                        $cat_ids[] = $new_cat;
                    }
                } else {
                    $cat_ids[] = $cat;
                }
            }
            if (!empty($cat_ids)) {
                wp_set_post_categories($post_id, $cat_ids);
            }
        }

        // Set tags
        if (!empty($tags)) {
            wp_set_post_tags($post_id, $tags);
        }

        // Set featured image from URL
        if (!empty($featured_image_url)) {
            $this->set_featured_image_from_url($post_id, $featured_image_url);
        }

        // Store meta description as post meta
        if (!empty($meta_description)) {
            update_post_meta($post_id, '_voicespark_meta_description', $meta_description);
            // Also update Yoast SEO meta if available
            update_post_meta($post_id, '_yoast_wpseo_metadesc', $meta_description);
        }

        $post = get_post($post_id);

        return new WP_REST_Response(array(
            'success' => true,
            'post_id' => $post_id,
            'post_url' => get_permalink($post_id),
            'post_status' => $post->post_status,
            'post_date' => $post->post_date,
            'message' => $status === 'future' 
                ? 'Post scheduled successfully.' 
                : 'Post created successfully.',
        ), 201);
    }

    /**
     * Update an existing blog post.
     */
    public function update_post($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $post_id = (int) $request->get_param('id');
        $post = get_post($post_id);

        if (!$post) {
            return new WP_Error('post_not_found', 'Post not found.', array('status' => 404));
        }

        $user = get_userdata($user_id);
        if (!$user || !user_can($user, 'edit_post', $post_id)) {
            return new WP_Error(
                'insufficient_permissions',
                'You do not have permission to edit this post.',
                array('status' => 403)
            );
        }

        $update_data = array('ID' => $post_id);

        $title = $request->get_param('title');
        if ($title !== null) {
            $update_data['post_title'] = sanitize_text_field($title);
        }

        $content = $request->get_param('content');
        if ($content !== null) {
            $update_data['post_content'] = wp_kses_post($content);
        }

        $status = $request->get_param('status');
        if ($status !== null) {
            $update_data['post_status'] = sanitize_text_field($status);
        }

        $excerpt = $request->get_param('excerpt');
        if ($excerpt !== null) {
            $update_data['post_excerpt'] = sanitize_text_field($excerpt);
        }

        $scheduled_date = $request->get_param('scheduled_date');
        if ($status === 'future' && !empty($scheduled_date)) {
            $update_data['post_date'] = get_date_from_gmt($scheduled_date);
            $update_data['post_date_gmt'] = $scheduled_date;
        }

        $result = wp_update_post($update_data, true);

        if (is_wp_error($result)) {
            return $result;
        }

        // Update categories
        $categories = $request->get_param('categories');
        if ($categories !== null) {
            $cat_ids = array();
            foreach ($categories as $cat_name) {
                $cat = get_cat_ID($cat_name);
                if ($cat === 0) {
                    $new_cat = wp_create_category($cat_name);
                    if (!is_wp_error($new_cat)) {
                        $cat_ids[] = $new_cat;
                    }
                } else {
                    $cat_ids[] = $cat;
                }
            }
            wp_set_post_categories($post_id, $cat_ids);
        }

        // Update tags
        $tags = $request->get_param('tags');
        if ($tags !== null) {
            wp_set_post_tags($post_id, $tags);
        }

        // Update featured image
        $featured_image_url = $request->get_param('featured_image_url');
        if (!empty($featured_image_url)) {
            $this->set_featured_image_from_url($post_id, esc_url_raw($featured_image_url));
        }

        $updated_post = get_post($post_id);

        return new WP_REST_Response(array(
            'success' => true,
            'post_id' => $post_id,
            'post_url' => get_permalink($post_id),
            'post_status' => $updated_post->post_status,
            'message' => 'Post updated successfully.',
        ), 200);
    }

    /**
     * Delete a blog post.
     */
    public function delete_post($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $post_id = (int) $request->get_param('id');
        $post = get_post($post_id);

        if (!$post) {
            return new WP_Error('post_not_found', 'Post not found.', array('status' => 404));
        }

        $user = get_userdata($user_id);
        if (!$user || !user_can($user, 'delete_post', $post_id)) {
            return new WP_Error(
                'insufficient_permissions',
                'You do not have permission to delete this post.',
                array('status' => 403)
            );
        }

        $force_delete = $request->get_param('force') === true;
        $result = wp_delete_post($post_id, $force_delete);

        if (!$result) {
            return new WP_Error('delete_failed', 'Failed to delete the post.', array('status' => 500));
        }

        return new WP_REST_Response(array(
            'success' => true,
            'message' => $force_delete ? 'Post permanently deleted.' : 'Post moved to trash.',
        ), 200);
    }

    /**
     * Get all posts for syncing with VoiceSpark dashboard.
     */
    public function get_posts($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $page = (int) ($request->get_param('page') ?? 1);
        $per_page = (int) ($request->get_param('per_page') ?? 10);
        $status = $request->get_param('status') ?? 'any';

        $args = array(
            'post_type'      => 'post',
            'post_status'    => $status,
            'posts_per_page' => min($per_page, 100),
            'paged'          => $page,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );

        $query = new WP_Query($args);
        $posts = array();

        foreach ($query->posts as $post) {
            $posts[] = array(
                'id'             => $post->ID,
                'title'          => $post->post_title,
                'excerpt'        => $post->post_excerpt,
                'status'         => $post->post_status,
                'date'           => $post->post_date,
                'date_gmt'       => $post->post_date_gmt,
                'modified'       => $post->post_modified,
                'url'            => get_permalink($post->ID),
                'author'         => get_the_author_meta('display_name', $post->post_author),
                'categories'     => wp_get_post_categories($post->ID, array('fields' => 'names')),
                'tags'           => wp_get_post_tags($post->ID, array('fields' => 'names')),
                'featured_image' => get_the_post_thumbnail_url($post->ID, 'full'),
            );
        }

        return new WP_REST_Response(array(
            'posts'       => $posts,
            'total'       => (int) $query->found_posts,
            'total_pages' => (int) $query->max_num_pages,
            'current_page'=> $page,
        ), 200);
    }

    /**
     * Get site information for connection verification.
     */
    public function get_site_info($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        return new WP_REST_Response(array(
            'site_name'    => get_bloginfo('name'),
            'site_url'     => get_bloginfo('url'),
            'description'  => get_bloginfo('description'),
            'wp_version'   => get_bloginfo('version'),
            'plugin_version' => '1.0.0',
            'timezone'     => wp_timezone_string(),
            'language'     => get_bloginfo('language'),
        ), 200);
    }

    /**
     * Get available categories.
     */
    public function get_categories($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $categories = get_categories(array('hide_empty' => false));
        $result = array();

        foreach ($categories as $cat) {
            $result[] = array(
                'id'    => $cat->term_id,
                'name'  => $cat->name,
                'slug'  => $cat->slug,
                'count' => $cat->count,
            );
        }

        return new WP_REST_Response($result, 200);
    }

    /**
     * Get available tags.
     */
    public function get_tags($request)
    {
        $user_id = $this->get_user_from_token();

        if (is_wp_error($user_id)) {
            return $user_id;
        }

        $tags = get_tags(array('hide_empty' => false));
        $result = array();

        foreach ($tags as $tag) {
            $result[] = array(
                'id'    => $tag->term_id,
                'name'  => $tag->name,
                'slug'  => $tag->slug,
                'count' => $tag->count,
            );
        }

        return new WP_REST_Response($result, 200);
    }

    /**
     * Decode JWT token and return user ID.
     */
    public function get_user_from_token()
    {
        $auth_header = isset($_SERVER['HTTP_X_VOICESPARK_AUTH']) 
            ? $_SERVER['HTTP_X_VOICESPARK_AUTH'] 
            : '';

        if (empty($auth_header)) {
            // Also check standard Authorization header
            $auth_header = isset($_SERVER['HTTP_AUTHORIZATION']) 
                ? str_replace('Bearer ', '', $_SERVER['HTTP_AUTHORIZATION']) 
                : '';
        }

        if (empty($auth_header)) {
            $this->error = new WP_Error(
                'missing_token',
                'Authentication token is missing.',
                array('status' => 401)
            );
            return $this->error;
        }

        try {
            JWT::$leeway = 240; // $leeway in seconds
            $token = JWT::decode(
                $auth_header,
                new Key(get_option('voicespark_secret'), 'HS256'),
            );

            if ($token->iss != get_bloginfo('url')) {
                $this->error = new WP_Error(
                    'bad_issuer',
                    'The issuer does not match with this server.',
                    array('status' => 401)
                );
                return $this->error;
            } elseif (!isset($token->data->user_id)) {
                $this->error = new WP_Error(
                    'bad_request',
                    'Incomplete token data.',
                    array('status' => 401)
                );
                return $this->error;
            } else {
                return $token->data->user_id;
            }
        } catch (Exception $e) {
            $this->error = new WP_Error(
                'invalid_token',
                $e->getMessage(),
                array('status' => 403)
            );
            return $this->error;
        }
    }

    /**
     * Filter: determine current user from VoiceSpark token.
     */
    public function determine_current_user($user)
    {
        $rest_api_slug = rest_get_url_prefix();
        $is_valid_rest_api_uri = strpos($_SERVER['REQUEST_URI'], $rest_api_slug);
        $is_valid_token_uri = strpos($_SERVER['REQUEST_URI'], $this->namespace . '/token');

        $is_voicespark_request = (
            isset($_SERVER['HTTP_USER_AGENT']) && $_SERVER['HTTP_USER_AGENT'] === 'VoiceSpark'
            && (isset($_SERVER['HTTP_X_VOICESPARK_AUTH']) || isset($_SERVER['HTTP_AUTHORIZATION']))
        );

        if ($is_voicespark_request && $is_valid_rest_api_uri && !$is_valid_token_uri) {
            $user_id = $this->get_user_from_token();
            if ($user_id && !is_wp_error($user_id)) {
                return $user_id;
            }
        }

        return $user;
    }

    /**
     * Filter: return error if authentication failed.
     */
    public function rest_pre_dispatch($request)
    {
        if (is_wp_error($this->error)) {
            return $this->error;
        }
        return $request;
    }

    /**
     * Helper: Set featured image from URL.
     */
    private function set_featured_image_from_url($post_id, $image_url)
    {
        require_once(ABSPATH . 'wp-admin/includes/media.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/image.php');

        $tmp = download_url($image_url);

        if (is_wp_error($tmp)) {
            return $tmp;
        }

        $file_array = array(
            'name'     => basename(parse_url($image_url, PHP_URL_PATH)),
            'tmp_name' => $tmp,
        );

        $attachment_id = media_handle_sideload($file_array, $post_id);

        if (is_wp_error($attachment_id)) {
            @unlink($tmp);
            return $attachment_id;
        }

        set_post_thumbnail($post_id, $attachment_id);
        return $attachment_id;
    }
}


// ============================================================
// Plugin Activation / Deactivation Hooks
// ============================================================

register_activation_hook(__FILE__, 'voicespark_activate');
register_deactivation_hook(__FILE__, 'voicespark_deactivate');

/**
 * On activation: generate a unique secret key for JWT signing.
 */
function voicespark_activate()
{
    // Generate a 256-character hex secret key
    add_option('voicespark_secret', bin2hex(random_bytes(128)));

    // Flush rewrite rules for REST API
    flush_rewrite_rules();
}

/**
 * On deactivation: clean up the secret key.
 */
function voicespark_deactivate()
{
    delete_option('voicespark_secret');
}

// ============================================================
// Initialize the Plugin
// ============================================================
$voicespark_plugin = new VoiceSpark_Auth();
$voicespark_plugin->run();
